
package model;


public class Integrante {
    private String nome;
    private int id;
    private String dataNas;
    private boolean estaVivo;
    private String dataObit;
    private String cpf;

    public Integrante(String nome, int id, String dataNas, boolean estaVivo, String dataObit, String cpf) {
        this.nome = nome;
        this.id = id;
        this.dataNas = dataNas;
        this.estaVivo = estaVivo;
        this.dataObit = dataObit;
        this.cpf = cpf;
    }

    public Integrante(String nome, String dataNas, String cpf) {
        this.nome = nome;
        this.dataNas = dataNas;
        this.cpf = cpf;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDataNas() {
        return dataNas;
    }

    public void setDataNas(String dataNas) {
        this.dataNas = dataNas;
    }

    public boolean isEstaVivo() {
        return estaVivo;
    }

    public void setEstaVivo(boolean estaVivo) {
        this.estaVivo = estaVivo;
    }

    public String getDataObit() {
        return dataObit;
    }

    public void setDataObit(String dataObit) {
        this.dataObit = dataObit;
    }

    
    
}
