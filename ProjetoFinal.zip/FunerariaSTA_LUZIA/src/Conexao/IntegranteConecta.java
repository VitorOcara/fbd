
package Conexao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.Cliente;
import model.Integrante;


public class IntegranteConecta {
    private final Connection connection;
    
    public IntegranteConecta(Connection connection) {
        this.connection = connection;
    }
    
    public void insert(Integrante integrante) throws SQLException{
        
            
            String sql = ("insert into integrantes(nome, data_nascimento, cpf) values ('"+integrante.getNome()+"','"+integrante.getDataNas()+"','"+integrante.getCpf()+"');");
            
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.execute();       
            connection.close(); 
         
    }
    
    
    public void delete(Integrante integrante) throws SQLException{
        
        String sql = ("delete from integrantes where nome = '"+integrante.getNome()+"';");
        
        PreparedStatement statement = connection.prepareStatement(sql);
            statement.execute();       
            connection.close(); 
     
    }
    
    
}
