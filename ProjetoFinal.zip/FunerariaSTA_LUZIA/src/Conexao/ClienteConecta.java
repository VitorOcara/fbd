
package Conexao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Cliente;

public class ClienteConecta {

    private final Connection connection;

    public ClienteConecta(Connection connection) {
        this.connection = connection;
    }
    
    public void insert(Cliente cliente) throws SQLException{
            
        
            
            String sql = ("insert into cliente(nome, cpf, tipo) values (?, ?, ?)");
            
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, cliente.getNome());
            statement.setString(2, cliente.getCpf());
            statement.setString(3, cliente.getPlano());
            
            statement.execute();       
            connection.close(); 
         
    }
    
    public void delete(Cliente cliente) throws SQLException{
        
        String sql = ("delete from cliente where nome = ?;");
        
        PreparedStatement statement = connection.prepareStatement(sql);
        
        statement.setString(1, cliente.getNome());
        statement.execute();       
        connection.close(); 
     
    }
    
    
    public void update(Cliente cliente) throws SQLException{
        
        String sql = ("update cliente set nome = ?, cpf= ?, tipo = ? where id_cliente = ?");
        
        
        PreparedStatement statement = connection.prepareStatement(sql);
        
        statement.setString(1, cliente.getNome());
        statement.setString(2, cliente.getCpf());
        statement.setString(3, cliente.getPlano());
        statement.setInt(4, cliente.getId());
        statement.execute();       
        connection.close(); 

    }
    
    
    public ArrayList<Cliente> selectAll() throws SQLException{        
        String sql = ("Select * from cliente");
        
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.execute();
        ResultSet resultSet = statement.getResultSet();
        
        ArrayList<Cliente> clientes = new ArrayList<>();
        
        while(resultSet.next()){
            int id = resultSet.getInt("id_cliente");
            String nome = resultSet.getString("nome");
            String cpf = resultSet.getString("cpf");
            String plano = resultSet.getString("tipo");
            
            
            
            Cliente cliDados = new Cliente(id, nome, cpf, plano);
            clientes.add(cliDados);
        }
        
        return clientes;
    }

    
}
